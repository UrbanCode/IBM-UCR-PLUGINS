/*
* Li/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
/* This is an example step groovy to show the proper use of APTool
 * In order to use import these utilities, you have to use the "pluginutilscripts" jar
 * that comes bundled with this plugin example.
 */
import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;

import com.urbancode.air.XTrustProvider;
import java.net.URI;
import java.nio.charset.Charset;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import org.apache.log4j.*

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.release.rest.models.internal.ApprovalItem;
import com.urbancode.air.XTrustProvider;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient
import org.apache.http.client.*
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import com.urbancode.release.rest.models.internal.TaskExecution;
import java.net.URI;

final def workDir = new File('.').canonicalFile

//Required imports
def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

//Required to access Release endpoints
def releaseToken = props['releaseToken'];
def extraProperties = props['extraProperties'];
//Useful for some operations
//it gets the ID of the integration provider running that step
def integrationProviderId = props['releaseIntegrationProvider'];

//All fields saved from the UI
//to be added automatically by the server
def serverUrl = props['releaseServerUrl'];
if (!serverUrl.endsWith("/")) {
    serverUrl = serverUrl+"/";
}

Clients.loginWithToken(serverUrl, releaseToken);

def provider = new PluginIntegrationProvider().id(integrationProviderId).get()
def existingMap = provider.getProperty("crMapping");
println existingMap
def slurper = new groovy.json.JsonSlurper()
def mappingStore = []
if (existingMap != null) {
     mappingStore = slurper.parseText(existingMap);
}

println "# tickets to check => "+mappingStore.size()
HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(apTool)
mappingStore.each {
    item->

    def sd = new ScheduledDeployment ()
    sd.format("report");
    sd = sd.id(item.id).get()

    if (sd.approval != null) {
        sd.approval.tasks.each {
           approval ->
           if ((approval.name == (props['approvalName']+" - # "+item.cr) || approval.name == (props['approvalName'])) && approval.status == "OPEN") {
               println "Opened approval handled in service now found for item #"+item.cr+" => "+approval.name+" with status "+approval.status

               try {
                   parsedApproval = helper.getApproval(item.cr)
                   if (parsedApproval == "approved") {
                       println "Approval handled in service now has been approved"
                       approval.approve()
                   }
                }
                catch (e) {
                    print e
                }
           }
        }
    }
}

