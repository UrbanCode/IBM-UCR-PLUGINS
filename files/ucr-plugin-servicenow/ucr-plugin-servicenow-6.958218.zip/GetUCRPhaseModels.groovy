#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.*
import com.urbancode.plugin.*;

import com.urbancode.plugin.*;
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.PhaseModel;
import com.urbancode.release.rest.models.internal.Lifecycle;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;


/**
 * Script for obtaining the phases in UCR. Primarily used for the integration's checked multi-
 * select for selecting phases.
 *
 * @author aberk
 */

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

// UCR auth variables
def token = props['releaseToken'];
def serverUrl = props['releaseServerUrl'];

// Establish the client connection
Clients.loginWithToken(serverUrl, token);

// POJO for output object
class Item { String label; String value }

// Resulting output list
items = [] as List

// Get all the Lifecycles
def lifecycles = (new Lifecycle()).getAll();

// Iterate through the lifecycles
lifecycles.each { lifecycle ->
    lifecycle.phaseModels.each { phaseModel ->
        // Get name of phase and lifecycle along with the phase model's ID
        def item = new Item(label: phaseModel.name + " - " + lifecycle.name, value: phaseModel.id);
        items.add(item);
    }
}

// Serialize and set output
def jsonBuilder = new groovy.json.JsonBuilder();
jsonBuilder(items);
print(jsonBuilder.toString());
setOutput(apTool, jsonBuilder.toString())

//--------------------------------------------------------------
def setOutput(AirPluginTool apTool, String value) {
    apTool.setOutputProperty("Output", value);
    apTool.storeOutputProperties();
}