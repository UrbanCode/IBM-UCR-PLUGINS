/*
* Li/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
/* This is an example step groovy to show the proper use of APTool
 * In order to use import these utilities, you have to use the "pluginutilscripts" jar
 * that comes bundled with this plugin example.
 */
import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;

import com.urbancode.air.XTrustProvider;
import java.net.URI;
import java.nio.charset.Charset;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import org.apache.log4j.*

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.release.rest.models.internal.ApprovalItem;
import com.urbancode.air.XTrustProvider;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient
import org.apache.http.client.*
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import com.urbancode.release.rest.models.internal.TaskExecution;
import java.net.URI;

import com.urbancode.air.FetchIntegrationHelper;

final def workDir = new File('.').canonicalFile

//Required imports
def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def integrationStartTime = System.currentTimeMillis();

def createdState = props['deploymentCreatedState']

//Required to access Release endpoints
def releaseToken = props['releaseToken'];
def extraProperties = props['extraProperties'];

def releaseField = props['releaseField'];
def envField = props['envField'];
def defaultEnv = props['defaultEnv'];
//Useful for some operations
//it gets the ID of the integration provider running that step
def integrationProviderId = props['releaseIntegrationProvider'];

//All fields saved from the UI
//to be added automatically by the server
def serverUrl = props['releaseServerUrl'];
if (!serverUrl.endsWith("/")) {
    serverUrl = serverUrl+"/";
}

Clients.loginWithToken(serverUrl, releaseToken);
def provider = new PluginIntegrationProvider().id(integrationProviderId).get()

/*
*
*   Query SNOW for latest records
*
*/

HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(apTool)

def lastExecutionTime = provider.getProperty("lastExecutionTime");
if(lastExecutionTime == null) {
    // First time we will get last hour of tickets
    lastExecutionTime = System.currentTimeMillis() - (60L * 60L * 1000L)
} else {
    lastExecutionTime = Long.parseLong(provider.getProperty("lastExecutionTime"));
}


def date = new Date(lastExecutionTime)

def timestamp = date.format("yyyy-MM-dd HH:mm:ss")

println "Check for tickets changed since => " + timestamp

//def ticketList = helper.getTicketTypeUpdatedSince("change_request", "2017-11-06 21:59:22")
def ticketList = helper.getTicketTypeUpdatedSince("change_request", timestamp)
println "Number of tickets to check => "+ ticketList.size()

// println ticketList[0].sys_updated_on

/*
*
*   Evaluate currently created deployments
*
*/

def existingMap = provider.getProperty("crMapping");
def slurper = new groovy.json.JsonSlurper()
def mappingStore = []
if (existingMap != null) {
     mappingStore = slurper.parseText(existingMap);
}

FetchIntegrationHelper fetchHelper = new FetchIntegrationHelper(provider);
ticketList.each { ticket ->
    if (fetchHelper.shouldCreateDeployment(ticket, releaseField, envField, createdState, defaultEnv)) {

        println "=============================="
        println "Creating deployment for ticket: (" + ticket.number + ") " + ticket.short_description

        def sd = fetchHelper.createScheduledDeployment(ticket[releaseField], ticket[envField], ticket.start_date, ticket.number, defaultEnv)

        println "Scheduled Deployment: " + sd.id
        println "=============================="

    }
}

/*
*
*   Check if approvals are complete
*
*/
mappingStore.each {
    item->

    def sd = new ScheduledDeployment ()
    sd.format("report");
    sd = sd.id(item.id).get()

    if (sd.approval != null) {
        sd.approval.tasks.each {
           approval ->
           if ((approval.name == (props['approvalName']+" - # "+item.cr) || approval.name == (props['approvalName'])) && approval.status == "OPEN") {
               println "Opened approval handled in service now found for item #"+item.cr+" => "+approval.name+" with status "+approval.status

               try {
                   parsedApproval = helper.getApproval(item.cr)
                   if (parsedApproval == "approved") {
                       println "Approval handled in service now has been approved"
                       approval.approve()
                   }
                }
                catch (e) {
                    print e
                }
           }
        }
    }
}


/*
*
*   Save execution time
*
*/

provider = provider.get();
provider = provider.property("lastExecutionTime", integrationStartTime.toString()).save();