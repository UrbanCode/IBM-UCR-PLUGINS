#!/usr/bin/env groovy
import com.urbancode.air.AirPluginTool
import com.urbancode.release.rest.framework.Clients

/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Release
* (c) Copyright IBM Corporation 2011, 2013. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2020. All Rights Reserved.
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.release.rest.models.internal.PluginIntegrationProvider
import com.urbancode.urelease.integration.jenkins.JenkinsEntityFactory
import com.urbancode.urelease.rest.JenkinsJob
import com.urbancode.urelease.rest.JenkinsRestHelper
import com.urbancode.release.rest.models.internal.TaskExecutionUpdate;
import com.urbancode.release.rest.models.internal.Comment;
import com.urbancode.release.rest.models.internal.TaskExecution;

import java.text.SimpleDateFormat

final def workDir = new File('.').canonicalFile
AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()

def jenkinsHostname = props['jenkinsHostName']
def jenkinsUser = props['jenkinsUser']
def jenkinsPassword = props['jenkinsPassword']
def jenkinsHelperImpl = new JenkinsRestHelper(jenkinsHostname, jenkinsUser, jenkinsPassword,true)

JenkinsIntegration integration = new JenkinsIntegration(props, jenkinsHelperImpl)
integration.releaseAuthentication()
integration.runIntegration()

public class JenkinsIntegration {
    final int MAX_QUERY = 500 // maximum number of arguments per sync query
    JenkinsRestHelper jenkinsRestHelper
    String timeout
    def currentJenkinsServerTime
    JenkinsEntityFactory entityFactory
    String jenkinsHostname
    String jenkinsUser
    String jenkinsPassword

    String integrationProviderId   // id of the integration provider that is running the script
    PluginIntegrationProvider integrationProvider
    String ucrServerUrl    // used to call ucr rest endpoint from the script
    String ucrToken        // token used to authenticate with the ucr server

    public JenkinsIntegration(def props, def jenkinsHelperImpl) {
        this.jenkinsRestHelper = jenkinsHelperImpl
        this.timeout = props['timeout']
        this.jenkinsHostname = props['jenkinsHostName']
        this.jenkinsUser = props['jenkinsUser']
        this.jenkinsPassword = props['jenkinsPassword']
        this.integrationProviderId = props['releaseIntegrationProvider']
        this.ucrServerUrl = props['releaseServerUrl']
        this.ucrToken = props['releaseToken']
        

        //If no value is set for the timeout then we set it to 0
        if (timeout == null || timeout == "") {
            timeout = 0;
        }
        else {
            try {
                timeout = Integer.parseInt(defaultTimeout);
                println("Timeout for http requests is set to "+timeout+"s ")
                //We convert it into milliseconds
                timeout = timeout * 1000;
            }
            catch (Exception ex) {
                printLog("WARNING", "The default timeout provided ("+timeout+") is not a number and no timeout will be set")
                timeout = 0;
            }
        }
    }
    // authenticate with uRelease server
    def releaseAuthentication () {
        Clients.loginWithToken(ucrServerUrl, ucrToken)
    }

    /*
     * Import all jobs, builds, and nodes in Jenkins as new applications, versions, and environments in UCR respectively
     */
    def runIntegration() {
        println "------------------------------------------------------------------------------------------------------------------------------"
        integrationProvider = new PluginIntegrationProvider().id(integrationProviderId).get()

        // Any interaction with client entity will begin using concrete entity's factory class.
        this.entityFactory = new JenkinsEntityFactory(jenkinsHostname, jenkinsUser, jenkinsPassword,Integer.parseInt(timeout));
        entityFactory.setProvider(integrationProvider);

        /* Import jobs and corresponding builds */
        List<JenkinsJob> jobs = entityFactory.getJenkinsJobs(jenkinsHostname);
        println("Jenkins Jobs imported: "+jobs.size())
        //Import Job Templates from UCD
        currentJenkinsServerTime = System.currentTimeMillis();
        importJobTemplates (jobs);
        integrationProvider.property("lastExecution", new SimpleDateFormat("MM/dd/yyy").format(new Date())).save()
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Update Executing Tasks
        updateExecutingTasks()
    }

    //--------------------------------------------------------------
    def importJobTemplates (List<JenkinsJob> jobs) {
       println "<b><u>>>>> Import Jenkins Job Templates</u></b>"
       int pageSize = 100;
       int pageNo = 1;
       entityFactory.syncJobTemplate(jobs);
    }

    /*
     * Print logs
     */
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
    
    
    //--------------------------------------------------------------
    def updateExecutingTasks () {
       println "<b><u>>>>> Update Executing Tasks</u></b>"
       //List of all processes from UCD that will be turned into UCR Automated Tasks
       def executingTask = new TaskExecution().getAllExecutingForProvider(integrationProvider.id.toString())
       println "# UCR Tasks to update: "+executingTask.size()
        def bulkTaskExecutionList = [] as List

        if (executingTask.size() > 0) {
            executingTask.each {
               item ->
              def task = item
              def processUpdate;
              def executionUpdateList = [] as List
              
              println "# item url : "+item.propertyValues.url
              println "# item nextBuildNumber : "+item.propertyValues.nextBuildNumber
              
              if (item.propertyValues.nextBuildNumber != null) {
                  processUpdate = jenkinsRestHelper.getJenkinsJobStatusForBuildNumber(item.propertyValues.url,item.propertyValues.nextBuildNumber)
		          
                  if(item.propertyValues.processRequestIdList==null) {
                      item.propertyValues.processRequestIdList = item.propertyValues.nextBuildNumber
                  }                 
                          try {
                              def taskUpdate = new TaskExecutionUpdate();
                              if (processUpdate != null && processUpdate.result != null) {
                                  if (processUpdate.result == "SUCCESS" || processUpdate.result == "FAILURE") {
                                      taskUpdate.status(TaskExecutionUpdate.Status.CLOSED)
                                  }

                                  if (processUpdate.result  == "NOT_BUILT") {
                                      taskUpdate.status(TaskExecutionUpdate.Status.PLANNED)
                                  }

                                  if (processUpdate.result  == "SUCCESS") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.SUCCEEDED)
                                  }
                             //If canceled from the uDeploy UI we mark the task as failed Similarly Same functioned we have added here
                                  if (processUpdate.result  == "ABORTED") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.CANCELED)
                                      taskUpdate.status(TaskExecutionUpdate.Status.CLOSED)
                                  }

                                  if (processUpdate.result == "FAILURE") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.FAULTED)
                                  }

                                  if (taskUpdate.result == null) {
                                      println "UCD Application Process ID "+item.propertyValues.nextBuildNumber +" did not return a valid result"
                                      println "Result not handled: "+processUpdate
                                  }
                                  executionUpdateList.add(taskUpdate)
                              }

                          }
                          //Here if for any reason the request hangs in Deploy we want to log it and keep going
                          //That task will be updated during the next run
                          //Timeout is set to 1 minute
                          catch (SocketTimeoutException ex) {
                              printLog("WARNING", ex)
                              printLog("WARNING", "Timeout occured while updating Jenkins Jobs ID: ")
                          }

                          // catch when process doesn't exist in Deploy
                          // update the task as failed in Release, as it is no longer a valid Deploy task
                          catch (RuntimeException ex) {
                              //printLog("WARNING", "Error trying to access UCD Application Process ID: " + processId)
                              printLog("WARNING", "Task '" + task.name + "' has been marked as failed, ID:" + task.id)

                              // fail the task instead of adding it to the update list because we don't have the
                              // application target id
                              task.fail()
                          }
                    if (executionUpdateList.size() > 0) {
                        item.taskUpdates(executionUpdateList.toArray(new TaskExecutionUpdate[executionUpdateList.size()]))
                        bulkTaskExecutionList.add(item)
                    }
               }
               else {
                   printLog("WARNING", "Task '" + task.name + "' has been marked as failed, ID:" + task.id)
                     // fail the task instead of adding it to the update list because we don't have the
                     // application target id
                     task.fail()
               }
        }

            if (bulkTaskExecutionList.size() > 0) {
                //We sync the Task Updates
                new TaskExecution().saveExecutingTasks(bulkTaskExecutionList.toArray(new TaskExecution[bulkTaskExecutionList.size()]))
            }
            else {
                println "No tasks to update"
            }
        }
        else {
           println "No Executing tasks to update"
        }
    }

}
