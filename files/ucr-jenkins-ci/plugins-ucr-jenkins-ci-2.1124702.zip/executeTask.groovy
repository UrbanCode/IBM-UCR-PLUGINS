/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Release
* (c) Copyright IBM Corporation 2011, 2013. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2020. All Rights Reserved.
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.AirPluginTool
import groovy.json.JsonSlurper
import org.apache.http.impl.client.HttpClientBuilder
import org.apache.http.entity.mime.MultipartEntityBuilder
import org.apache.http.entity.mime.content.FileBody
import org.apache.http.impl.client.CloseableHttpClient
import org.codehaus.jettison.json.JSONArray
import org.codehaus.jettison.json.JSONObject
import org.apache.http.client.methods.HttpPost;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils
import com.urbancode.urelease.rest.JenkinsRestHelper
import org.apache.http.Header

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
def _props = apTool.getStepProperties()

def jenkinsHostname = _props['jenkinsHostName']
def jenkinsUser = _props['jenkinsUser']
def jenkinsPassword = _props['jenkinsPassword']
def jenkinsHelperImpl = new JenkinsRestHelper(jenkinsHostname, jenkinsUser, jenkinsPassword,true)

//We launch the integration here
TaskExecution integration = new TaskExecution(apTool,jenkinsHelperImpl)
integration.executeTask();

public class TaskExecution {

    String timeout;
    String jenkinsAPIToken;
    String jenkinsUserName;
    String extraProperties;
    JSONObject taskProperties;
    AirPluginTool apTool
    Properties props;
    JenkinsRestHelper jenkinsRestHelper;

    //Main constructor
    TaskExecution(apTool, jenkinsHelperImpl) {
        this.jenkinsRestHelper = jenkinsHelperImpl;
        this.apTool = apTool;
        props = apTool.getStepProperties();
        extraProperties = props['extraProperties'];
        timeout = props['timeout']
        jenkinsUserName = props['jenkinsUser']
        jenkinsAPIToken = props['jenkinsAPIToken']
        taskProperties = new JSONObject(extraProperties);
    }

    //--------------------------------------------------------------
    def executeTask() {
        if (timeout == "" || timeout == null) {
            timeout = "0"
        }
        def slurper = new JsonSlurper();
        def extraProperties = slurper.parseText(extraProperties);
        String jenkinsJobURL = extraProperties.task.properties.url;
        boolean isParameterizedBuild = false;

        if (jenkinsJobURL != null) {
            String buildParameters = extraProperties.task.properties.PluginProperties;
            if (buildParameters != null) {
                isParameterizedBuild = true;
            }
            triggerJenkinsBuild(jenkinsJobURL, isParameterizedBuild, buildParameters)
        } else {
            System.out.println("Error:Jenkins Job URL is empty.")
        }
    }

    /**
     * This method will fetch the URL and build parameters configured for the jenkins-task configured from UrbanCode Release
     * @param jenkinsJobURL
     * @param isParameterizedBuild
     * @param buildParameters
     * @return
     * @throws IOException
     */
    String triggerJenkinsBuild(String jenkinsJobURL, boolean isParameterizedBuild, String buildParameters) throws IOException {
        String triggerJobURI = null;
        String status = null;
        if (isParameterizedBuild) {
            triggerJobURI = "buildWithParameters";
        } else {
            triggerJobURI = "build";
        }

        String triggerBuildURL = jenkinsJobURL.concat(triggerJobURI);
        String encodeAuthToken = Base64.getEncoder().encodeToString((jenkinsUserName + ":" + jenkinsAPIToken).getBytes());

        println ("The Job Trigger URI : "+triggerBuildURL)
        HttpPost httpPost = new HttpPost(triggerBuildURL);
        httpPost.addHeader("Authorization", "Basic " + encodeAuthToken);

        if (isParameterizedBuild && buildParameters != null) {
            httpPost.setEntity(getBuildParamsAsURLEncodedEntity(buildParameters));
        }
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse responsePost = httpClient.execute(httpPost);
        println responsePost.getStatusLine().getStatusCode();
        println responsePost.getStatusLine().getReasonPhrase();
        println responsePost.getStatusLine().toString();
        status = EntityUtils.toString(responsePost.getEntity());
                
        try {
            Header locationHeader = responsePost.getFirstHeader("location")
            String location = locationHeader.getValue()
            int buildNo  = jenkinsRestHelper.getJenkinsJobBuildNumber(location)
            status = status + "Job build number "+buildNo; 
            println ("Job build number "+buildNo)
        }
        catch (Exception e) {
            System.out.println("Error : Build number not created")
        }
        return status;
    }

    /**
     * The parameters array from the parsed text from JsonSlurper will be passed to this method.
     * Converts the string into a JSON array and generate a list of BasicNameValuePairs objects for the POST API
     * @param buildParams
     * @return
     */
    HttpEntity getBuildParamsAsURLEncodedEntity(String buildParams) {
        JSONObject propDefJsonObject = null;
        MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();
        JSONArray taskPropsArray = new JSONArray(buildParams);
        boolean isFileParam = false;
        String propertyValue = "";
        for (int i = 0; i < taskPropsArray.length(); i++) {
            propDefJsonObject = taskPropsArray.getJSONObject(i);
            propertyValue = propDefJsonObject.getString("value");
            if (propertyValue.indexOf(':\\') != -1 || propertyValue.indexOf(':/') != -1) {
                File file = new File(updateFilePath(propertyValue.toString().trim()));
                if (file.isFile() && file.exists()) {
                    FileBody fileBody = new FileBody(file);
                    entityBuilder.addPart(propDefJsonObject.getString("name"), fileBody);
                    isFileParam = true;
                }
                else{
                    // Jenkins will not run the build if the file path does not exist.
                    println("");
                    throw new FileNotFoundException(file.getPath(),"The file configured for File-Parameter either does not exist or cannot be accessed");
                }
            }
            if (propertyValue != null && propertyValue.trim().length() > 0 && !isFileParam) {
                entityBuilder.addTextBody(propDefJsonObject.getString("name"), propertyValue);
            }
        }
        return entityBuilder.build();
    }

    /**
     * This method is used to handle escape characters found in the file path.
     * @param filePath
     * @return
     */
    String updateFilePath(String filePath) {
        String updatedFilePath = null;
        String replaceBackSlash = "\\\\";
        if (filePath != null) {
            int colonIdx = filePath.indexOf(':');
            if (colonIdx != -1) {
                char slashChar = filePath.charAt(colonIdx + 1);
                if (slashChar == '/') {
                    updatedFilePath = filePath.replaceAll(String.valueOf(slashChar), "/");
                }
                if (slashChar == '\\') {
                    updatedFilePath = filePath.replaceAll(String.valueOf(replaceBackSlash), "/");
                }
            }
        }
        return updatedFilePath;
    }
}










