/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Release
* (c) Copyright IBM Corporation 2011, 2013. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2020. All Rights Reserved.
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.AirPluginTool
import groovy.json.JsonSlurper
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.impl.client.HttpClients
import org.codehaus.jettison.json.JSONObject
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils
import com.urbancode.urelease.rest.JenkinsRestHelper

import groovyx.net.http.*
import org.apache.http.Header

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
def _props = apTool.getStepProperties()

def jenkinsHostname = _props['jenkinsHostName']
def jenkinsUser = _props['jenkinsUser']
def jenkinsPassword = _props['jenkinsPassword']
def jenkinsHelperImpl = new JenkinsRestHelper(jenkinsHostname, jenkinsUser, jenkinsPassword,true)

//We launch the integration here
TaskExecution integration = new TaskExecution(apTool,jenkinsHelperImpl)
integration.executeTask();

public class TaskExecution {

    String timeout;
    String jenkinsAPIToken;
    String jenkinsUserName;
    String extraProperties;
    JSONObject taskProperties;
    AirPluginTool apTool
    Properties props;
    JenkinsRestHelper jenkinsRestHelper;

    //Main constructor
    TaskExecution(apTool, jenkinsHelperImpl) {
        this.jenkinsRestHelper = jenkinsHelperImpl;
        this.apTool = apTool;
        props = apTool.getStepProperties();
        extraProperties = props['extraProperties'];
        timeout = props['timeout']
        jenkinsUserName = props['jenkinsUser']
        jenkinsAPIToken = props['jenkinsAPIToken']
        taskProperties = new JSONObject(extraProperties);
    }

    //--------------------------------------------------------------
    def executeTask() {
        if (timeout == "" || timeout == null) {
            timeout = "0"
        }
        def slurper = new JsonSlurper();
        def extraProperties = slurper.parseText(extraProperties);
        String jenkinsJobURL = extraProperties.task.properties.url;
        if(jenkinsJobURL != null){
            triggerJenkinsBuild(jenkinsJobURL)
        }
        else{
            System.out.println("Error:Jenkins Job URL is empty.")
        }
    }

    /**
     * This method will fetch the URL for the jenkins-task configured fro UrbanCode Release
     * @param jenkinsJobURL
     * @return
     * @throws IOException
     */
    String triggerJenkinsBuild(String jenkinsJobURL) throws IOException {
        String triggerJobURI = null;
        String status = null;
        if(false){
            triggerJobURI = "buildWithParameters";
        } else {
            triggerJobURI = "build";
        }

        String triggerBuildURL = jenkinsJobURL.concat(triggerJobURI); //.concat(jenkinsAPIToken);

        String encodeAuthToken = Base64.getEncoder().encodeToString((jenkinsUserName + ":" + jenkinsAPIToken).getBytes());

        println ("The Job Trigger URI : "+triggerBuildURL)
        HttpPost httpPost = new HttpPost(triggerBuildURL);
        httpPost.addHeader("Authorization", "Basic " + encodeAuthToken)
        httpPost.addHeader("Accept", "application/json")
        httpPost.addHeader("Content-Type", "application/json")
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpResponse responsePost = httpClient.execute(httpPost);
        println responsePost.getStatusLine().getStatusCode();
        println responsePost.getStatusLine().getReasonPhrase();
        println responsePost.getStatusLine().toString();
        status = EntityUtils.toString(responsePost.getEntity());
                
        try {
            Header locationHeader = responsePost.getFirstHeader("location")
            String location = locationHeader.getValue()
            int buildNo  = jenkinsRestHelper.getJenkinsJobBuildNumber(location)
            status = status + "Job build number "+buildNo; 
            println ("Job build number "+buildNo)
        }
        catch (Exception e) {
            System.out.println("Error : Build number not created")
        }
        return status;
    }
}










