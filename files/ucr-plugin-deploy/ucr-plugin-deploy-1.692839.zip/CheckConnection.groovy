#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import com.urbancode.air.XTrustProvider;
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.air.XTrustProvider;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient
import org.apache.http.client.*
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import com.urbancode.urelease.rest.Rester;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;


final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def deployHostName = props['deployHostName']
def deployToken = props['deployToken']
def rester = new Rester(deployHostName, deployToken);
	
try {
    def result = rester.getOnUrl("/release/integrationVersion");
	
	println "IBM UrbanCode Release was able to connect to the following server"
	println deployHostName
	
	def slurper = new JsonSlurper();
    def resultJson = slurper.parseText(result)

	println "Using Protocol Version: "+resultJson.integrationVersion
} catch (Exception e) {
    println "Unable to connect to UCD."
	
	def listOfHints =  rester.getHelpOnConnectionException(e);

	listOfHints.each{
		key -> 
		println "-"+key;
	}
	println "-----------------------------------------";
    println "Exception:";
	println e;
	println "Cause:";
	println e.cause;
	println "-----------------------------------------";
    throw new RuntimeException();
}