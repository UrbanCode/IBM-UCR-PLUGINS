package com.urbancode.plugin

import com.urbancode.air.*
import com.urbancode.plugin.models.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;

public class ApprovalSerializer {

    def sd;
    def syncId;
    def integrationId;

    def teams = [];
    def teamIds = [];
    def userIds = [];

    public ApprovalSerializer(scheduledDeployment, syncId, integrationId) {
        sd = scheduledDeployment;
        this.syncId = syncId;
        this.integrationId = integrationId;
    }

    def serializeApprovals() {

        def result = [] as List;

        def user = sd.creator.get();

        for (task in sd.approval.tasks) {
            teams = [];
            teams.add(new NameIdPair(id: sd.release.teamId, name: sd.release.teamName));
            def approval = new Approval(
                id: task.id,
                type: "Approval",
                subtype: "Release",
                context: (new ApprovalContext(
                    name: task.name,
                    environment: sd.environment.name,
                    phase: sd.phase.phaseModel.name,
                    release: sd.release.name
                    )),
                requestor: new User(id: user.id, name: user.name, email: user.email, phone: user.phone, displayName: user.actualName),
                commentEnabled: false,
                commentRequired: false,
                requestedDate: sd.dateCreated,
                scheduledDate: sd.scheduledDate,
                status: task.status,
                teams: teams,
                role: new NameIdPair(id: task.executorRole.id, name: task.executorRole.name),
                syncId: syncId,
                integrationId: integrationId
            )

            result.add(approval);
        }

        return result;
    }

    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
}

