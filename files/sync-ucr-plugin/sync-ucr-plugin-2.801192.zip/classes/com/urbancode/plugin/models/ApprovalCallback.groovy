package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the deployment json doc
public class ApprovalCallback {
    def action_item_id;
    def action_sync_id;
    def action_instance_id;
    def result;
    def error;
}
