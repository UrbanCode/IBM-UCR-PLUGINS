package com.urbancode.plugin

import com.urbancode.air.*
import com.urbancode.plugin.models.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;

public class TaskSerializer {

    def sd;
    def syncId;
    def integrationId;

    def teams = [];
    def teamIds = [];
    def userIds = [];
    
    def users;
    
    def taskList;

    public TaskSerializer(scheduledDeployment, taskList, syncId, integrationId, users) {
        sd = scheduledDeployment;
        this.syncId = syncId;
        this.integrationId = integrationId;
        this.taskList = taskList;
        this.users = users;
    }

    def serializeTasks() {

        def result = [] as List;

        def user = sd.creator.get();

        def _deleted = false;
        if(sd.deploymentExecution.status != "INPROGRESS") {
            _deleted = true;
        }
        
        for (task in taskList) {
            def userId = task.userId;
            def userEmail = users.get(userId) == null ? null : users.get(userId).getEmail();
            teams = [];
            teams.add(new NameIdPair(id: sd.release.teamId, name: sd.release.teamName));
            
            def responseOptions;
            
            if(task.status.toLowerCase() == "executing") {
                responseOptions = ["succeeded", "failed", "skipped"];
            }
            if(task.status.toLowerCase() == "open") {
                responseOptions = ["started", "succeeded", "failed", "skipped"];
            }
            
            def requestedDate = task.startTimeActual == null ? task.startTimeEstimated : task.startTimeActual;

            def approval
            if(_deleted) {
                approval = new ApprovalDeleted(
                    id: task.id,
                    type: "Task",
                    subtype: "Release",
                    name: task.name,
                    context: (new ApprovalContext(
                            name: task.name,
                            environment: sd.environment.name,
                            phase: sd.phase.phaseModel.name,
                            release: sd.release.name
                            )),
                    commentEnabled: true,
                    commentRequired: false,
                    scheduledDate: task.startTimePlanned,
                    requestedDate: requestedDate,
                    status: task.status,
                    teams: teams,
                    userEmail: userEmail,
                    responseOptions : responseOptions,
                    role: task.executorRole == null ? null : new NameIdPair(id: task.executorRole.id, name: task.executorRole.name),
                    syncId: syncId,
                    integrationId: integrationId,
                    _deleted: true
                )
            }
            else {
                approval = new Approval(
                    id: task.id,
                    type: "Task",
                    subtype: "Release",
                    name: task.name,
                    context: (new ApprovalContext(
                            name: task.name,
                            environment: sd.environment.name,
                            phase: sd.phase.phaseModel.name,
                            release: sd.release.name
                            )),
                    commentEnabled: true,
                    commentRequired: false,
                    scheduledDate: task.startTimePlanned,
                    requestedDate: requestedDate,
                    status: task.status,
                    teams: teams,
                    userEmail: userEmail,
                    responseOptions : responseOptions,
                    role: task.executorRole == null ? null : new NameIdPair(id: task.executorRole.id, name: task.executorRole.name),
                    syncId: syncId,
                    integrationId: integrationId,
                )
            }

            result.add(approval);
        }

        return result;
    }

    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
}

