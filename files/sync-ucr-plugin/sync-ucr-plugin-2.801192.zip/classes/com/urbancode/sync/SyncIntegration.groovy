package com.urbancode.sync

import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.*;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.internal.mapper.ObjectMapperType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.ResponseSpecification;

import static com.jayway.restassured.RestAssured.given;


public class SyncIntegration extends IntegrationProvider {
    { path = "api/integrations/"; }
    
    private String syncBaseUrl = "https://localhost:8443";
    private String syncToken;
    
    public SyncIntegration setSyncAuth(String syncBaseUrl, String syncToken) {
        this.syncBaseUrl = syncBaseUrl;
        this.syncToken = syncToken;
        return this;
    }
    
    public Response getResponse() {
        log.debug("getResponse()");
        ResponseSpecification rs = query.apply(given().baseUri(syncBaseUrl)).header("Authorization", "CloudSyncToken " + syncToken).expect().contentType(ContentType.JSON).when();
        return rs.get(path(id));
    }
    
    public Response put() {
        log.debug("put()");
        return query.apply(given().baseUri(syncBaseUrl)).header("Authorization", "CloudSyncToken " + syncToken).body(this, ObjectMapperType.GSON).put(writePath(id));
    }
}