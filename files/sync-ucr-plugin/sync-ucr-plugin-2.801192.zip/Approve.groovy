#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
 
import com.urbancode.air.*
import com.urbancode.plugin.*;

import static com.jayway.restassured.RestAssured.*;

import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;
import com.urbancode.release.rest.models.AuthenticationToken;
import com.urbancode.release.rest.models.internal.ApprovalItem;

import com.urbancode.plugin.UCCloudClient;
import com.urbancode.plugin.models.ApprovalCallback;

import com.urbancode.release.rest.models.internal.*;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

println props;

def uri = props['uri'];
def token = props['token'];
def user = props['user']
def approvalId = props['approvalId'];
def action = props['action'];
def comments = props['comments'];

def result = "failed";
def error = "No Error"

def cloudHelper;

println "Approving ${approvalId} as user ${user}";

println "Logging in to ${uri} as admin"
def adminTokenJson = '{ "token": "' + token + '" }';

def integrationProviderId = props['releaseIntegrationProvider'];
def syncId = props['sync.id'];
def syncToken = props['sync.token'];

def cloudUrl
def environment = props['sync.environment']
if(environment == "dev") {
    cloudUrl = "https://ucmobile-cloud-sync-apiv2-dev.mybluemix.net";
}
else {
    cloudUrl = "https://ucmobile-cloud-sync-apiv2.mybluemix.net";
}

cloudHelper = new UCCloudClient (cloudUrl, syncId, syncToken, integrationProviderId)

try {
    Clients.loginWithToken(uri, adminTokenJson);
    println "Logged in"
}
catch (Exception e) {
    error = "Could not connect to UrbanCode Release"
    cloudHelper.postActionItemCallback(new ApprovalCallback(action_item_id: approvalId, action_sync_id: syncId, action_instance_id: integrationProviderId, result: result, error: error));
    throw e;
}

if (user) {
    // approve as a specific user, requires the token given to be and admin token
    def userId;
    try {
        userId = UUID.fromString(user);
    }
    catch (IllegalArgumentException e) {
        if (user.indexOf("@") > 0) {
            println "Looking up user by email..."
            def filteredUsers = Clients.user().filter("email", FilterClass.STRING, FilterType.EQUALS, user).when().getAll();
            if (!filteredUsers || filteredUsers.length == 0) {
                throw new Exception("User not found: ${user}");
            }
            userId = filteredUsers[0].id;
            println "Found ${userId} for email ${user}"
        }
        else {
            println "Looking up user by username..."
            def filteredUsers = Clients.user().filter("name", FilterClass.STRING, FilterType.EQUALS, user).when().getAll();
            if (!filteredUsers || filteredUsers.length == 0) {
                throw new Exception("User not found: ${user}");
            }
            userId = filteredUsers[0].id;
            println "Found ${userId} for username ${user}"
        }
    }

    println "Creating temporary token for user id ${userId}"
    def userTokenExpiration = System.currentTimeMillis() + 60000L;
    def userToken = new AuthenticationToken()
        .user(Clients.user().id(userId))
        .expiration(userTokenExpiration)
        .description("Cloud Sync Approval Token - Delete Me")
        .host("")
        .save();
    try {
        println "Created temporary token for user id ${userId}";
        def userTokenJson = '{ "token": "' + userToken.token + '" }';
        Clients.loginWithToken(uri, userTokenJson);

        if(action.equalsIgnoreCase("approved")) {
            
            def tempSD = new ScheduledDeployment();
            tempSD.format("deploymentstab");
            tempSD.filter("approval.tasks.id", FilterClass.UUID, FilterType.EQUALS, approvalId);
            
            def tempResult = tempSD.getAll();
            
            given().multiPart("scheduledDeployment", tempResult[0].id).when()put(new ApprovalItem().path(approvalId) + "/approve");
            println "Approval ${approvalId} approved";
//            if(tempResult != null && tempResult.size() > 0) {
//                tempResult[0].deploymentExecution.invalidateCache();
//            }
        }
        else {
            def notStarted = false;
            if(new TaskExecution().id(approvalId).get().status == "OPEN") {
                notStarted = true
            }
            if (action.equalsIgnoreCase("started")) {
                new TaskExecution().id(approvalId).start();
            }
            else if (action.equalsIgnoreCase("succeeded")) {
                if(notStarted) {
                    new TaskExecution().id(approvalId).start();
                }
                new TaskExecution().id(approvalId).complete();
            }
            else if (action.equalsIgnoreCase("failed")) {
                if(notStarted) {
                    new TaskExecution().id(approvalId).start();
                }
                new TaskExecution().id(approvalId).fail();
            }
            else if (action.equalsIgnoreCase("skipped")) {
                if(notStarted) {
                    new TaskExecution().id(approvalId).start();
                }
                new TaskExecution().id(approvalId).skip();
            }
            
            if(comments != null && comments != "") {
                new TaskComment().task(new TaskExecution().id(approvalId)).comment(comments).save();
            }
            
            result = "passed";
            cloudHelper.postActionItemCallback(new ApprovalCallback(action_item_id: approvalId, action_sync_id: syncId, action_instance_id: integrationProviderId, result: result, error: error));
        }
    }
    catch (Exception e2) {
        error = "Failed to take action in UrbanCode Release"
        cloudHelper.postActionItemCallback(new ApprovalCallback(action_item_id: approvalId, action_sync_id: syncId, action_instance_id: integrationProviderId, result: result, error: error));
        throw e2;
    } 
    finally {
        userToken.delete();
        println "Temporary token deleted";
    }
}
else {
    // approve with the token we already have
    given().put(new ApprovalItem().path(approvalId) + "/approve");
    println "Approval ${approvalId} approved";
}