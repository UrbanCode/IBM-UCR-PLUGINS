package com.urbancode.sync

import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.*;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.internal.mapper.ObjectMapperType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.ResponseSpecification;

import static com.jayway.restassured.RestAssured.given;

public class SyncIntegration extends IntegrationProvider {
    { path = "api/integrations/"; }

    private String syncBaseUrl = "https://localhost:8443";
    private String syncToken;

    public SyncIntegration setSyncAuth(String syncBaseUrl, String syncToken) {
        this.syncBaseUrl = syncBaseUrl;
        this.syncToken = syncToken;
        return this;
    }

    public Response getResponse() {
        log.info("Getting integration properties");
        Response response = query.apply(given().baseUri(syncBaseUrl)).header("Authorization", "CloudSyncToken " + syncToken).expect().contentType(ContentType.JSON).statusCode(200).get(path(id));
        log.debug("Received 200 response getting integration properties")
        return response
    }

    public Response put() {
        log.info("Saving integration properties");
        Response response = query.apply(given().baseUri(syncBaseUrl)).header("Authorization", "CloudSyncToken " + syncToken).header("Content-Type", "application/json").body(this, ObjectMapperType.GSON).put(writePath(id)).then().statusCode(200).extract().response();
        log.debug("Received 200 response setting integration properties")
        return response
    }
}
