package com.urbancode.plugin

import com.urbancode.air.*

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.urbancode.release.rest.models.User;

public class SeedHandler {

    def static seededIds = ["00000000-0000-0000-0000-000000000206"];

    public TeamSerializer(id, name, user_list) {
        deploymentId = id;
        deploymentName = name;
        userList = user_list;
    }

    public static handle(id) {
		if(seededIds.contains(id)) {
			return combineIds(id, UCRIdentifier.getUCR_ID());
		}
		return id;
	}
	
	private static combineIds(idA, idB) {
		return xor(idA.getBytes(), idB.getBytes()).encodeBase64().toString();
	}
	
	private static xor(byte[] a, byte[] key) {
        byte[] out = new byte[a.length];
        for (int i = 0; i < a.length; i++) {
            out[i] = (byte) (a[i] ^ key[i%key.length]);
        }
        return out;
    }
}