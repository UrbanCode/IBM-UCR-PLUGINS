package com.urbancode.plugin

import com.urbancode.air.*

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.urbancode.release.rest.models.Role;
import com.urbancode.plugin.models.Team;

public class TeamRoleSerializer {

    def teamId;
    def teamName;
    def roleUserMap;

    public TeamRoleSerializer(id, name, role_user_map) {
        teamId = SeedHandler.handle(id);
        teamName = name;
        roleUserMap = role_user_map;
    }

    def serializeToObject() {
        def rolesMap = [:];

        roleUserMap.each { entry ->
            rolesMap.put(entry.key.getId(), new RoleObj(id: entry.key.getId(), name: entry.key.getName(), users:generateUserList(entry.value)));
        }

        return new Team(id: teamId, name:teamName, roles: rolesMap);
    }

    def generateUserList(userList) {
        def users = [];
        userList.each { user ->
            users << new User(id: user.id, name: user.name, email: user.email, phone: user.phone, displayName: user.actualName);
        }
        return users;
    }
}

public class RoleObj {
    def id;
    def name;
    def users;
}

