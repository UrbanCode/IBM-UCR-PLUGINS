package com.urbancode.plugin.models

public class User {
    def id;
    def name;
    def email;
    def phone;
    def displayName;
}