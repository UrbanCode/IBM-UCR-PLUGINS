package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the deployment json doc
public class ApprovalDeleted extends Approval {
    def _deleted;
}
