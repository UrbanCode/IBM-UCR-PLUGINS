package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for basic task tag object
public class TaskTagObject {
    def name;
    def color;
    def totalTasks;
    def completeTasks;
    def inProgressTasks;
    def failedTasks;
    def users;
    def startTimeActual;
    def startTimePlanned;
    def startTimeEstimated;
    def endTimeActual;
    def endTimePlanned;
    def endTimeEstimated;
}