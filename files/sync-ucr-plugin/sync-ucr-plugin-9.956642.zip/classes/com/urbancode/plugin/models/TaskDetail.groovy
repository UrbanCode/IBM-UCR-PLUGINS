package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for details of deployment dashboard
public class TaskDetail {
    def id;
    def name;
    def startTime;
    def startTimePlanned;
    def duration;
    def endTime;
    def userId;
    def userName;
    def userPhone;
    def status;
    def role;
}