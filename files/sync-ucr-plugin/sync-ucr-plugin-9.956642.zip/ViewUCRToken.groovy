#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
 
import com.urbancode.air.*
import com.urbancode.plugin.*;

import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

Security.insertProviderAt(new BouncyCastleProvider(),1);

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

println "ucr_token";
println "--------------------------";
println props['ucr_token'];
