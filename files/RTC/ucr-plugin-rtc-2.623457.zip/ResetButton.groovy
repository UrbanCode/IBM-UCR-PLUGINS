#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;


final def workDir = new File('.').canonicalFile

import com.urbancode.urelease.plugin.helper.*;
import com.urbancode.release.rest.models.Change;
import com.urbancode.release.rest.models.Initiative;
import com.urbancode.release.rest.framework.Clients;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def integrationProviderId = props['releaseIntegrationProvider'];
def releaseToken = props['releaseToken'];
def serverUrl = props['releaseServerUrl'];


//--------------------------------------------------------------
//Authentication with Release
def releaseAuthentication (serverUrl, releaseToken) {
    Clients.loginWithToken(serverUrl, releaseToken)
}
//Authentication
releaseAuthentication (serverUrl, releaseToken)

println("")
new Change().deleteAllForIntegrationProvider(integrationProviderId)
new Initiative().deleteAllForIntegrationProvider(integrationProviderId)

def allChanges = new Change().getAllForIntegrationProvider(integrationProviderId)
if (allChanges.size() > 0) {
     throw new Exception("Changes could not be deleted!")
}
else {
    println("All changes have been deleted successfully")
}

def allInitiatives = new Initiative().getAllForIntegrationProvider(integrationProviderId)
if (allInitiatives.size() > 0) {
    throw new Exception("Initiative could not be deleted!")
}
else {
   println("All initiatives have been deleted successfully")
}
