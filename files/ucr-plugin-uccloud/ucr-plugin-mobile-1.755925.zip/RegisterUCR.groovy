#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.*
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

import com.urbancode.plugin.*;
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def cloudUrl = "https://uccloud.mybluemix.net";

def integration = new UCCloudClient(cloudUrl)

def releaseToken = props['releaseToken'];
def serverUrl = props['releaseServerUrl'];

Clients.loginWithToken(serverUrl, releaseToken);

def result = new UCRRegistrant(
    admin_name: props['adminName'],
    admin_email: props['adminEmail'],
    admin_phone: props['adminPhone'],
    site_id: props['siteId'],
    ucr_id: UCRIdentifier.getUCR_ID());

def ucr_token = integration.registerUCR(result);

println "--------------------------"
println "UrbanCode Release is registered and auth token is received";
println "--------------------------\n";

def integrationProviderId = props['releaseIntegrationProvider'];
def provider = new PluginIntegrationProvider().id(integrationProviderId).get();
provider.setProperty("ucr_token", ucr_token).save();

//--------------------------------------------------------------
// POGO for UCR Instance Registration
public class UCRRegistrant {
    String admin_name;
    String admin_email;
    String admin_phone;
    String ucr_id;
    String site_id;
}

//--------------------------------------------------------------
//Print logs
def printLog(type, message) {
    println "<span class=\""+type+"\">"+message+"</span>"
}
