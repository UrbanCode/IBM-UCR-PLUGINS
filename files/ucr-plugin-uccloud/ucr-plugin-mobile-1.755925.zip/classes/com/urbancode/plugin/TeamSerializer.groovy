package com.urbancode.plugin

import com.urbancode.air.*

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.urbancode.release.rest.models.User;

public class TeamSerializer {

    def teamId;
    def teamName;
    def userList;

    public TeamSerializer(id, name, user_list) {
        teamId = SeedHandler.handle(id);
        teamName = name;
        userList = user_list;
    }

    public TeamSerializer() {
    }

    def serializeToObject() {
        def users = generateUserList(userList);

        return new Team(id: teamId, name:teamName, users: users);
    }

    def generateUserList(userList) {
        def users = [];
        userList.each { user ->
            users << new User(id: user.id, name: user.name, email: user.email, phone: user.phone, displayName: user.actualName);
        }
        return users;
    }
}


public class Team {
    def ucr_token;
    def id;
    def name;
    def users;
}

public class User {
    def id;
    def name;
    def email;
    def phone;
    def displayName;
}