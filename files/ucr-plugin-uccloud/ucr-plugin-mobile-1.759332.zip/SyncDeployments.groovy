#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
 
import com.urbancode.air.*
import com.urbancode.plugin.*;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

println "ucr_token";
println "--------------------------";
def ids = props['deploymentID'].split(',');

println ids;

def id = ids[0];

def releaseToken = props['releaseToken'];
def serverUrl = props['releaseServerUrl'];

Clients.loginWithToken(serverUrl, releaseToken);

def sd = (new ScheduledDeployment()).id(id).get();

def startTime;
if(sd.deploymentExecution.status == "NOTSTARTED") {
	startTime = sd.scheduledDate;
}
else {
	startTime = sd.deploymentExecution.startTimeActual;
}

def lateCount = 0;
def waitingCount = 0;
def errorCount = 0;

def env = new nameIdPair(name: sd.environment.name, id: sd.environment.id);
def rel = new nameIdPair(name: sd.release.name, id: sd.release.id);
def phase = new nameIdPair(name: sd.phase.name, id: sd.phase.id);
def detail = generateGraphData(sd);
def teams = new nameIdPair[1];
teams[0] = new nameIdPair(name: sd.release.teamName, id: sd.release.teamId);

def result = new Deployment(
	updatedTime: System.currentTimeMillis(),
	id: sd.id,
	name: generateName(sd),
	level: "DEPLOYMENT",
	environment: env,
	release: rel,
	phase: phase,
	startTime: startTime,
	plannedEndTime: sd.deploymentExecution.endTimePlanned,
	estimatedEndTime: sd.deploymentExecution.endTimeEstimated,
	lineGraph: detail.lineGraph,
	teams: teams,
	taskStatus: detail.taskStatus,
	progress: detail.progress);
	

def ucr_token = props['ucr_token'];
def cloudUrl = props['cloudHostName'];
println "^^^^^ " + ucr_token;
def integration = new UCCloudClient(cloudUrl, ucr_token);
integration.postDeployment((Object)result);;


//--------------------------------------------------------------
// POGO for UCR Instance Registration
public class nameIdPair {
	String name;
	String id;
}

def generateName(sd) {
	return sd.release.name + ": " + sd.environment.name + " at " + (new Date(sd.scheduledDate))
}

public class Deployment {
	def ucr_token;
	def environment;
	def release;
	def phase;
	def id;
	def level;
	def startTime;
    def plannedEndTime;
    def estimatedEndTime;
	def name;
	def updatedTime;
	def lineGraph;
	def teams;
	def taskStatus;
	def progress;
}

def generateGraphData(sd) {
	def minTime;
	def lateCount = 0;
	def waitingCount = 0;
	def errorCount = 0;
	def progress = 0;

	def numIntervals = 20;
	
	if(sd.deploymentExecution.status == "NOTSTARTED") {
		minTime = sd.scheduledDate;
	}
	else {
		minTime = Math.min(sd.scheduledDate, sd.deploymentExecution.startTimeActual);
	}
	
	def maxTime;
	if(sd.deploymentExecution.endTimeEstimated != null) {
		maxTime = Math.max(sd.deploymentExecution.endTimePlanned, sd.deploymentExecution.endTimeEstimated);
	}
	else {
		maxTime = sd.deploymentExecution.endTimePlanned;
	}
	def taskCount = 0;
	
	def intervalSize = (int)((maxTime - minTime) / numIntervals);
	
	GraphDataPoint[] dataPoints = new GraphDataPoint[numIntervals];
	def actualCount = new Integer[numIntervals];
	def estimatedCount = new Integer[numIntervals];
	def plannedCount = new Integer[numIntervals];
	
	for(int i = 0; i < numIntervals; i++) {
		actualCount[i] = 0;
		estimatedCount[i] = 0;
		plannedCount[i] = 0;
	}
	
	if(sd.deploymentExecution.segments != null) {
		sd.deploymentExecution.segments.each { segment ->
			if(segment.tasks != null) {
				segment.tasks.each { task ->
					taskCount++;
					
					if(task.status == "OPEN") {
						waitingCount++;
					}
					else if(task.status == "EXECUTING" && task.startTimeActual > task.startTimePlanned) {
						lateCount++;
					}
					else if(task.status == "CLOSED" && task.result == "FAILURE") {
						errorCount++;
					}
				
					def plannedEnd = (task.startTimePlanned + (int)(task.duration * 60 * 1000));
					def iPlanned = (int)((plannedEnd - minTime) / intervalSize);

					if(iPlanned == numIntervals) {
						iPlanned--;
					}

					plannedCount[iPlanned]++;
					
					if(task.endTimeActual != null) {
						def actualEnd = task.endTimeActual;
						def iActual = (int)((actualEnd - minTime) / intervalSize);
						
						if(iActual == numIntervals) {
							iActual--;
						}
						
						actualCount[iActual]++;
					}
					else if(task.startTimeEstimated != null) {
						def estimatedEnd = task.startTimeEstimated + (task.duration * 60 * 1000)
						def iEstimated = (int)((estimatedEnd - minTime) / intervalSize);
						
						if(iEstimated == numIntervals) {
							iEstimated--;
						}
						
						estimatedCount[iEstimated]++;
					}
				}
			}
		}
	}
	
	def isActualInterval = true;
	
	def lastPlanned = 0;
	def lastActual = 0;
	def lastEstimated = 0;
		
	for(int i = 0; i < numIntervals; i++) {

		if(isActualInterval) {
			dataPoints[i] = new GraphDataPoint(
				timestamp: (minTime + (int)(i * intervalSize)),
				plannedCount: plannedCount[i] + lastPlanned,
				actualCount: actualCount[i] + lastActual);
			
			lastActual = actualCount[i] + lastActual;
			
			if(estimatedCount[i] > 0) {
				lastEstimated = estimatedCount[i] + lastActual;
				isActualInterval = false;
			}
		}
		else {
			dataPoints[i] = new GraphDataPoint(
				timestamp: (minTime + (int)(i * intervalSize)),
				plannedCount: plannedCount[i] + lastPlanned,
				estimatedCount: estimatedCount[i] + lastEstimated);
				
			lastEstimated = estimatedCount[i] + lastEstimated;
		}
		
		lastPlanned = plannedCount[i] + lastPlanned;
	}
	
	return new DeploymentDetail(
		lineGraph:(new LineGraphObject(
			taskCount: taskCount,
			minTime: minTime,
			maxTime: maxTime,
			dataPoints: dataPoints)),
		taskStatus: new TaskStatusCount(
			late:lateCount,
			waiting: waitingCount,
			error: errorCount),
		progress: progress);
}

public class LineGraphObject {
	def taskCount;
	def minTime;
	def maxTime;
	def dataPoints;
}

public class GraphDataPoint {
	def timestamp;
	def plannedCount;
	def actualCount;
	def estimatedCount;
}

public class TaskStatusCount {
	def late;
	def waiting;
	def error;
}

public class DeploymentDetail {
	def progress;
	def taskStatus;
	def lineGraph;
}