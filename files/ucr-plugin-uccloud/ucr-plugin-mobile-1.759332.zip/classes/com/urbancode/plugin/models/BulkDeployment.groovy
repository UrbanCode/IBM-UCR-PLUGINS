package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the collection of deployments in a request
public class BulkDeployment {
	def ucr_token;
	def deployments;
}
