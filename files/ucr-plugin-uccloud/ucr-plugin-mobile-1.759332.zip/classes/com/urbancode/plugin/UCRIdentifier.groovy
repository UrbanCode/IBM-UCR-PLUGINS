package com.urbancode.plugin

import com.urbancode.air.*

import static java.util.UUID.randomUUID 

public class UCRIdentifier {
	//--------------------------------------------------------------
	// Function for getting UCR ID
	public static getUCR_ID() {

		def folder = new File("util/UCR")

		if(!folder.exists()) {
		  folder.mkdirs();
		}
		
		def idFile = new File(folder, "ucr.id")

		if( !idFile.exists() ) {
			idFile.withWriterAppend { file ->
			  file << (randomUUID() as String)
			}
		}
		
		return idFile.text;
	}
}