#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;

import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;

import com.urbancode.air.XTrustProvider;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient
import org.apache.http.client.*
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;

final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def rallyUrl = props['rallyUrl']
def projectArea = props['projectArea']

def jsonArray = null;

try {
    println "URL:"+rallyUrl

    HttpClientBuilder builder = new HttpClientBuilder();
    builder.setTrustAllCerts(true);

    def client = builder.buildClient();
    
    HttpGet methodGet = new HttpGet(rallyUrl);
    HttpResponse responseGet = client.execute(methodGet);
    
    int status = responseGet.getStatusLine().getStatusCode();
    
    if (status == HttpStatus.SC_OK) {
        println "The connection was successful";
    }
    else {
        //We throw an error if we can not connect to that URL it will be displayed in red on the integration provider page
        throw new Exception(String.format("%d", status));
    }
    
    println "-------------------------------------------------------------------------------"
    println "Connection Successful"
    println "-------------------------------------------------------------------------------"
}
catch (e) {
    def analysedOutput = generateHelpMessageFromError (e.getMessage());
    println "-------------------------------------------------------------------------------"
    println "Connection Failed"
    println "-------------------------------------------------------------------------------"
    throw new Exception("Error connecting to the Rally Server <br/>"+e.getMessage());
}
