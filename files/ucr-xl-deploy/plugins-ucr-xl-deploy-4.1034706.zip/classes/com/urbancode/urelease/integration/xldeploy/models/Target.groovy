/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
package com.urbancode.urelease.integration.xldeploy.models

/**
 * JSON data pertaining to an application target will be deserialzied into this class object.
 */
class Target {
    String name
    String externalId
    String externalUrl
}
