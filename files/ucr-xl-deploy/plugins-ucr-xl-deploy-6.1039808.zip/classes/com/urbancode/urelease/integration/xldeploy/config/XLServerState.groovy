/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
package com.urbancode.urelease.integration.xldeploy.config

public enum XLServerState {
    RUNNING("RUNNING"),
    MAINTENANCE("MAINTENANCE")

    private String state

    public XLServerState(String state) {
        this.state = state
    }

    public boolean equalsIgnoreCase(String value) {
        return value.equalsIgnoreCase(state)
    }

    @Override
    public String toString() {
        return this.state
    }

}
