/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
import com.urbancode.air.AirPluginTool
import com.urbancode.release.rest.models.internal.TaskExecution
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider
import com.urbancode.urelease.integration.xldeploy.Integration
import com.urbancode.urelease.integration.xldeploy.TaskExecutor

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()
TaskExecutor executor = new TaskExecutor(props)
executor.releaseAuthentication()
TaskExecution taskExecution = executor.executeTask()

executor.postComment(taskExecution,
    "Completed execution, this task will be updated once the corresponding XL Deploy tasks finish.")
