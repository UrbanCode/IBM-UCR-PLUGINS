package com.urbancode.urelease.integration.xldeploy.hash

import org.apache.commons.codec.digest.DigestUtils

class HashUtility {

    public static String hashReference(String reference) {
        String md5Hash = DigestUtils.md5Hex(reference)

        return md5Hash
    }
}
