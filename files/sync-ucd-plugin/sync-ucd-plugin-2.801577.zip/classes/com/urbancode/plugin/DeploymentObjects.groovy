package com.urbancode.plugin

//--------------------------------------------------------------
// POGO for UCR Instance Registration
public class nameIdPair {
    String name;
    String id;
}

//--------------------------------------------------------------
// POGO for the deployment json doc
public class Deployment {
    def ucr_token;
    def environment;
    def release;
    def phase;
    def id;
    def level;
    def startTime;
    def plannedEndTime;
    def estimatedEndTime;
    def name;
    def updatedTime;
    def lineGraph;
    def teams;
    def taskStatus;
    def status;
    def progress;
}

//--------------------------------------------------------------
// POGO for the collection of deployments in a request
public class BulkDeployment {
    def ucr_token;
    def deployments;
}

//--------------------------------------------------------------
// POGO for the line graph on the dashboard
public class LineGraphObject {
    def taskCount;
    def minTime;
    def maxTime;
    def dataPoints;
}

//--------------------------------------------------------------
// POGO for specific data point on line graph
public class GraphDataPoint {
    def timestamp;
    def plannedCount;
    def actualCount;
    def estimatedCount;
}

//--------------------------------------------------------------
// POGO for basic task counts
public class TaskStatusCount {
    def late;
    def waiting;
    def error;
}

//--------------------------------------------------------------
// POGO for details of deployment dashboard
public class DeploymentDetail {
    def progress;
    def taskStatus;
    def lineGraph;
}

//--------------------------------------------------------------
// POGO for details of deployment dashboard
public class TaskDetail {
    def id;
    def name;
    def startTime;
    def startTimePlanned;
    def duration;
    def endTime;
    def userId;
    def userName;
    def userPhone;
    def status;
}