package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the deployment json doc
public class Approval {
    def type;
    def subtype;
    def context;
    def requestor;
    def commentEnabled;
    def commentRequired;
    def commentPrompt;
    def requestedDate;
    def scheduledDate;
    def status;
    def role;
    def teams;
    def id;
    def syncId;
    def integrationId;
}
