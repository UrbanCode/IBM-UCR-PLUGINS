package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the Approval Context
public class ApprovalContext {
    def name;
    def environment;
    def application;
    def process;
}
