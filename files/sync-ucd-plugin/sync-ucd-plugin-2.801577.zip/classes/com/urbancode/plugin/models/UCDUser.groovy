package com.urbancode.plugin.models

public class UCDUser {
    def id;
    def name;
    def email;
    def phone;
    def actualName;
}