package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the collection of deployments in a request
public class BulkApproval {
    def ucr_token;
    def actionItems;
}
