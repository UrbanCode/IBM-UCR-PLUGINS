#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*
import com.urbancode.plugin.*;
import com.urbancode.plugin.models.*;

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.urbancode.sync.*;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import static com.jayway.restassured.RestAssured.expect;
import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.RestAssured.requestSpecification;
import static com.jayway.restassured.RestAssured.responseSpecification;

import com.urbancode.plugin.models.NameIdPair;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import java.security.cert.X509Certificate;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;

import com.google.gson.JsonParser;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import com.google.gson.Gson;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def integration = new CloudIntegration (props)

def totalStart = System.currentTimeMillis()

//We launch the full Integration
integration.runIntegration ()

public class CloudIntegration {

    def token;
    def serverUrl;
    def currentDeployServerTime;
    def cloudHelper;
    def deployHelper;
    def slurper;
    def deploymentNameMap = [:];
    def deploymentTeamMap = [:];
    def deploymentUserMap = [:];
    def teamUserMap = [:];
    def integrationProviderId;
    def syncId;
    def syncToken;
    def syncUrl;
    def provider;
    def lastExecutionTime;
    def lastTeamSyncTime;
    def importRange;
    def testUsersString;

    def approvals = [] as List;

    Set<String> userBlackList = new HashSet<String>();

    // We paginate the updating of entities to UCR.  We limit it to this number
    // for all entities
    def limitPerQuery = 500;

    public CloudIntegration (props) {
        slurper = new groovy.json.JsonSlurper();

        integrationProviderId = props['releaseIntegrationProvider'];
        syncId = props['sync.id'];
        syncToken = props['sync.token'];
        syncUrl = props['sync.url'];
        
        def cloudUrl
        def environment = props['sync.environment']
        if (environment == "dev") {
            cloudUrl = "https://ucmobile-cloud-sync-apiv2-dev.mybluemix.net";
        }
        else if (environment == "test") {
            cloudUrl = "https://ucmobile-cloud-sync-apiv2-test.mybluemix.net";
        }
        else {
            cloudUrl = "https://ucmobile-cloud-sync-apiv2.mybluemix.net";
        }

        token = props['token'];
        serverUrl = props['uri'];
        testUsersString = props['testUsers'];

        importRange = props['importRange'];

        if(importRange == null || importRange == "") {
            importRange = 14;
        }
        else {
            importRange = Long.valueOf(importRange);
        }

        cloudHelper = new UCCloudClient(cloudUrl, syncId, syncToken, integrationProviderId);
        deployHelper = new UCDeployClient(serverUrl, token);

        integrationProviderId = props['releaseIntegrationProvider'];
        syncId = props['sync.id'];

        // This is a Groovy class that extend the UCR client IntegrationProvider and overrides the
        // endpoints used.  Otherwise it behaves exactly the same
        provider = new SyncIntegration().setSyncAuth(syncUrl, syncToken).id(integrationProviderId);
        
        configureSSL("https://localhost:8443");
        provider = provider.get();
        provider.setSyncAuth(syncUrl, syncToken);
        
        lastExecutionTime = provider.getProperty("lastExecutionTime");
        lastTeamSyncTime = provider.getProperty("lastTeamSyncTime");
        if(lastExecutionTime == null) {
            lastExecutionTime = (System.currentTimeMillis()) - ((Long)importRange * 24 * 60 * 60 * 1000);
        }
        
        if(lastTeamSyncTime == null) {
            lastTeamSyncTime = 0;
        }
    }

    //--------------------------------------------------------------
    def runIntegration () {
        def integrationStartTime = System.currentTimeMillis();
        
        println "------------------------------------------------------------------------------------------------------------------------------"
        syncTeams();
        syncApprovals();

        provider.setSyncAuth(syncUrl, syncToken);
        provider = provider.property("lastExecutionTime", integrationStartTime.toString()).save();
        provider.setSyncAuth(syncUrl, syncToken);
    }

    def numItems = 0;
    
    def syncTeams() {
        
        println "Starting Sync Teams"
        def startTime = System.currentTimeMillis();

        // Skip if ten minutes has not passed
        if(startTime < Long.valueOf(lastTeamSyncTime) + (10 * 60 * 1000)) {
            def messages = ["Teams are synced every 10 minutes.  Skipped team sync this integration"] as String[];
            printStepInfo(startTime, "Sync Teams", messages);
            return;
        }
        
        def teamsJsonArray = deployHelper.getTeams(0);
        def rolesJsonArray = deployHelper.getRoles(0);
        
        def teams = [];
        
        Gson gson = new Gson();
        
        def testUsers;
        
        if(testUsersString != null && testUsersString != "") {
            testUsers = getTestUsers();
            printLog("bold", "Using test users")
            printLog("bold", testUsers.size() + " test users found")
        }
        
        //Iterate through teams
        for(teamObj in teamsJsonArray) {
            def rolesMap = [:]
            for(role in rolesJsonArray) {
                def userSet
                if (testUsers == null) {
                    userSet = deployHelper.getUsersInRoleOnTeam(teamObj.id, role.id);
                }
                else { 
                    userSet = testUsers;
                }
                
                rolesMap.put(new NameIdPair(id: role.id, name: role.name), userSet);
            }
            
            def team = new TeamRoleSerializer(teamObj.id, teamObj.name, rolesMap).serializeToObject();

            teams.add(team);
            numItems++;
        }
        
        cloudHelper.postTeams(new BulkTeam(teams: teams));
        
        provider.setSyncAuth(syncUrl, syncToken);
        provider = provider.property("lastTeamSyncTime", startTime.toString()).save();
        provider.setSyncAuth(syncUrl, syncToken);
        
        def messages = ["No. of Teams: " + numItems] as String[];
        printStepInfo(startTime, "Sync Teams", messages);
    }

    def getTestUsers() {
        def testEmails = [] as List;
        def result = [] as List;
        String[] testEmailArr = testUsersString.split(",");
        for(int i = 0; i < testEmailArr.length; i++) {
            testEmails.add(testEmailArr[i].trim());
        }

        for(testEmail in testEmails) {
            def tempUser = deployHelper.getUserByEmail(testEmail);
            result.add(deployHelper.getUserDetail(tempUser.id));
        }

        return result;
    }

    def syncApprovals() {
        def startTime = System.currentTimeMillis();
        def approvals = deployHelper.getApprovals(lastExecutionTime);

        def approvalsSerialized = new ApprovalSerializer(approvals, syncId, integrationProviderId).serializeApprovals();
        
        if(approvals.size() > 0) {
            cloudHelper.postBulkApprovals(new BulkApproval(actionItems: approvalsSerialized));
        }
        
        def messages = ["No. of Approvals: " + approvalsSerialized.size()] as String[];
        printStepInfo(startTime, "Sync Approvals", messages);
    }

    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    //--------------------------------------------------------------
    //Print step info
    def printStepInfo(startTime, stepDisplayName, messages) {
        printLog("TRACE", "--- "+ stepDisplayName +" ---");
        if(messages !=  null) {
            messages.each{ message -> printLog("TRACE", message) };
        }
        println "Step completed in " + (int)((System.currentTimeMillis() - startTime) / 1000) + " sec";
    }
    
    def configureSSL(baseUrl) {
        //SSL Strategy
        def sslFactory;
        def url = baseUrl;

        try {
            //We need to allow self signed certificates
            TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] certificate, String authType) {
                    return true;
                }
            };

            sslFactory = new SSLSocketFactory(acceptingTrustStrategy,
                //allow all host names since the installer creates a certificat for localhost but for sure the
                //customer will use his own domain name with that certificate
                SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

            requestSpecification = given().config(RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(sslFactory)));

            URL serverUrl = new URL(url);

            //If the protocol is https and no port is provided explicitly we need to default to 443
            if (serverUrl.getProtocol().equals("https")) {
                if (serverUrl.getPort() == -1) {
                    requestSpecification = given().port(443);
                }
            }

        } catch (Exception ex) {
            printLog("ERROR", "Can not apply SSL strategy "+ ex);
        }
    }
}

public class RoleObj {
    def id;
    def name;
    def users;
}
